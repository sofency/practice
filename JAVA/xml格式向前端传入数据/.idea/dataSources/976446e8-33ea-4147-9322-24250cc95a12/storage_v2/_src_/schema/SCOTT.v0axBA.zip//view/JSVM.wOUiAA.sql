CREATE VIEW JSVM AS 
select SC.Sno,SC.Cno,SC.Grade from stu,SC where ((stu.Sno=SC.Sno)and stu.Sdept='CS')
/

