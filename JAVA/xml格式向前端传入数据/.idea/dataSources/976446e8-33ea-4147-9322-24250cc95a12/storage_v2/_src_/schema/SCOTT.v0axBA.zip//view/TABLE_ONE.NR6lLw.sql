CREATE VIEW TABLE_ONE AS 
select ename,empno,job
from emp
where sal>2000 and sal <5000
/

