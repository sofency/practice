CREATE VIEW EMP1 AS 
select empno,ename,job from emp where sal<5000 with read only
/

